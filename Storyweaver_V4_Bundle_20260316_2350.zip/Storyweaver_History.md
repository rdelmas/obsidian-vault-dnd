# STORYWEAVER — HISTORIQUE & CONTEXTE PORTABLE

- Consolide décisions & fichiers clés de cette conversation
- À coller tel quel pour redémarrer le cadre de travail

## Fichiers clés
- 01_Master_Prompt_v4_Core.md
- ANNEXES — Storyweaver Structures & Schemas.md
- ANNEXES — Storyweaver Stats & Feats.md
- Context_Storyweaver.md
- PC_Tyron-Salun_PC-0001.md (à conserver dans /Players/)
