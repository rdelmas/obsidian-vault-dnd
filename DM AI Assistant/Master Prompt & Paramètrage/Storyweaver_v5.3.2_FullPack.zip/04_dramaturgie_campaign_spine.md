---
id: "DR-CAMPAIGN-SPINE"
title: "Colonne vertébrale de campagne"
category: "narrative"
status: "active"
last_updated: "2026-03-19"
file_role: "spine"
file_version: "1.0"
story_mode: "story-first"
structure: "acts"
default_beats: 5
tone: "mix"
themes: []
---

## START — Point de départ
→ À définir.

## DESTINATION — Objectif majeur
→ À définir.

# Acts, Waypoints, Beats, etc.
