---
id: "SETTINGS-MECHANICS"
title: "Paramètres mécaniques"
category: "settings"
status: "validated"
last_updated: "2026-03-19"
file_role: "settings"
file_version: "1.0"
system: "DnD 2024"
style: "Mix"
sources: ["PHB 2024", "DMG 2024", "MM 2024"]
stat_blocking: "suggestion"
roll_policy: "on_request"
default_difficulty: "Medium"
party_size: 3
party_composition:
  - name: "Van Elfling"
    id: "PC-0004"
  - name: "Maëlle"
  - name: "Ouka"
---
