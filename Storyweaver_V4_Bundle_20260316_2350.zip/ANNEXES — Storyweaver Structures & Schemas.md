# ANNEXES — Storyweaver Structures & Schemas (Obsidian-ready)

> Charge ce fichier quand Storyweaver te le demande (commande “CHARGER ANNEXES — STRUCTURES & SCHEMAS”).
> Contient : frontmatters (PC/NPC/LORE/REF/SETTINGS/SESSION) + structures (Lore, PC, NPC Standard/Miniboss/Boss).

---

## 1) YAML — Registry (Frontmatters officiels)

### 1.1 Player Character — PC-XXXX
```yaml
---
id: "PC-XXXX"
title: "Nom du personnage"
category: "player"
status: "pending"
last_updated: "YYYY-MM-DD"
race: ""
class: ""
subclass: ""
domain: ""
divine_order: ""
level: ""
background: ""
alignment: ""
origin: ""
family_role: ""
speed: ""
size: ""
passive_perception: ""
hit_die: ""
hp_max: ""
ac: ""
illustration: ""
tags:
  - "player"
  - "party"
  - "levelX"
  - "pending"
---
```

### 1.2 NPC — N-XXXX
```yaml
---
id: "N-XXXX"
title: "Nom du PNJ"
category: "npc"
status: "pending"
last_updated: "YYYY-MM-DD"
role: ""
species: ""
affiliation: ""
location: ""
importance: ""
alignment: ""
illustration: ""
tags:
  - "npc"
  - "status/pending"
---
```

### 1.3 Lore Entry — L-XXXX
```yaml
---
id: "L-XXXX"
title: "Titre"
category: "location"   # location|faction|culture|cosmology|event|item|magic|other
status: "pending"
last_updated: "YYYY-MM-DD"
source: "conversation" # conversation|obsidian|import
source_file: ""
validation_source: ""
refs_included: []
refs_excluded: []
illustration: ""
tags:
  - "lore/<category>"
  - "status/pending"
---
```

### 1.4 Reference — R-XXXX
```yaml
---
id: "R-XXXX"
title: "Titre de l’œuvre"
medium: "Film|Livre|Jeu|Art|Série"
status: "pending"         # validated|dismissed|pending
last_updated: "YYYY-MM-DD"
influence_mode: "SOFT"    # SOFT|HARD
included: []
excluded: []
notes: ""
tags:
  - "reference"
  - "status/pending"
---
```

### 1.5 Settings Mechanics — SETTINGS-MECH-0001
```yaml
---
id: "SETTINGS-MECH-0001"
title: "Paramètres mécaniques DnD 5e"
category: "settings"
status: "validated"
last_updated: "YYYY-MM-DD"
source: "conversation"
source_file: ""
validation_source: "User confirmation"
illustration: ""
tags:
  - "settings/mechanics"
  - "status/validated"
---
```

### 1.6 Session Notes — S-XXXX
```yaml
---
id: "S-XXXX"
title: "Session YYYY-MM-DD"
category: "session"
status: "validated"
last_updated: "YYYY-MM-DD"
summary_for: ["players","storyweaver"]
tags:
  - "session"
---
```

---

## 2) Formats — Structures des notes .md

### 2.1 LORE ENTRY — Structure standard
```markdown
## Résumé (1–3 phrases)
Résumé clair, court, autoporteur. Contexte + angle principal.

## Détail
- Contexte :
- Particularités :
- Lieux / acteurs impliqués :
- Intrigues liées :
- Liens : [[...]] (backlinks vers PJ/PNJ/autres entrées)

## Hooks & Utilisations
- Hook personnel :
- Hook du monde :
- Hook mystère :

## Canon & Retcon
- Points validés :
- Contradictions potentielles :
- Propositions (retcon/coexistence/dismiss) :
- Change Log :
  - [YYYY-MM-DD] Création (pending).
```

### 2.2 NPC — Standard / Miniboss (rappel court)
```markdown
## NPC Standard — Statblock court
- CA / PV / Vitesse
- Caractéristiques (FOR… CHA)
- JS / Compétences / Résist.
- Actions / Réactions
- Tactiques (1–2 lignes)

## NPC Miniboss — Statblock
- + Multiattaque
- + Traits (Commandement, Détermination…)
- + Action Bonus
- + Tactiques
```

### 2.3 PLAYER CHARACTER — Structure Générique (Narratif + Mécaniques)
```markdown
## Résumé
2–4 phrases — identité, rôle, origine, intentions.

## Profil & Personnalité
- Traits :
- Idéaux :
- Liens :
- Défauts :
### Historique
5–10 lignes ; backlinks utiles.
### Informations en attente (Pending)
- …

## Mécaniques (Générique & Complètes)
### Caractéristiques
FOR [ ] ([ ]) • DEX [ ] ([ ]) • CON [ ] ([ ]) • INT [ ] ([ ]) • SAG [ ] ([ ]) • CHA [ ] ([ ])
### Défenses & PV
CA [ ] ; PV [ ] ; DV [ ] ; Vitesse [ ] ; Initiative mod DEX ; Résist./Immun./Vuln. (si)
### Maîtrises
JS [ ] ; Compétences [ ] ; Armes [ ] ; Armures [ ] ; Outils [ ] ; Langues [ ]
### Équipement
Liste essentielle
### Aptitudes (universelles)
Aptitudes de classe (si) ; Sous-classe/Archétype (si) ; Capacités raciales ; Dons (si)
### Magie (optionnelle — si applicable)
DD = 8 + PB + mod ; Jet att. = PB + mod ; Cantrips [ ] ; Sorts N1 [ ] …

## Actions
Actions (arme/technique/sort), Actions Bonus, Réactions

## Hooks & Dramaturgie
- Personnel :
- Monde :
- Mystère :
Backlinks : [[...]]

## Canon & Retcon
Points validés ; contradictions ; propositions ; Change Log (dates)
```

### 2.4 NPC — Boss / Élite (Structure Générique)
```markdown
## Statblock (Boss)
Nom/Titre ; Type & Taille ; CA ; PV ; Vitesse ; PB
Caractéristiques (FOR… CHA)
JS ; Compétences ; Résist./Immun./Vuln. ; Sens ; Langues ; FP

### Traits passifs
- Thème/présence
- Résistance légendaire (3/jour)
- Autres

### Actions
Multiattaque (2–3) ; Attaque signature ; Pouvoir/Technique

### Actions Bonus
- …

### Réactions
- …

### Actions Légendaires (3)
- Mouvement
- Frappe rapide
- Pouvoir mineur

### Actions de Repaire (opt)
- Effet enviro / renfort

### Phases & Tactiques
P1 ; P2 (≤50% PV) ; (P3)
```
