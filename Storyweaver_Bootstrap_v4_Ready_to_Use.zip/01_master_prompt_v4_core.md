# Master Prompt — Storyweaver v4 (Core)
# Collez ici le bloc "Master Prompt v4 — contenu minimal" depuis le Manuel v4 (section 3).
