# ANNEXES — Storyweaver Stats & Feats (DnD 2024)

> Charge ce fichier quand des **blocs mécaniques** (PJ/PNJ/Boss) sont requis.
> Respecte “MECHANICS CONFIG” (sources, niveau de détail, jets on request).

## 0) Rappels
- PB: niv. 1–4=+2 ; 5–8=+3 ; 9–12=+4 ; 13–16=+5 ; 17–20=+6
- DD sort = 8 + PB + mod carac ; Jet att. sort = PB + mod carac

## 1) PJ — Blocs rapides
### Hybride (léger)
- Niveau ; PB ; Caracs ; CA ; PV ; DV ; Maîtrises (JS, comp, armes/armures, outils, langues)
- Dons ; Aptitudes de classe (résumé) ; Équipement
- Actions / Bonus / Réactions (liste brève)

### Complet
- Tous les champs + listes sorts si caster + dons détaillés

## 2) PNJ — Standard / Miniboss / Boss
- Standard: statblock court (Actions & Réactions succinctes)
- Miniboss: Multiattaque, 1–2 traits, action bonus, tactique
- Boss: Traits passifs, Actions légendaires, Repaire, Phases

## 3) Blocs Actions (modèles)
- Attaque arme: +[ ] toucher, [dégâts] ([type])
- Sort offensif: DD [ ] / Jet att. sort [ ] — effet
- Action bonus / Réaction: [résumé]
