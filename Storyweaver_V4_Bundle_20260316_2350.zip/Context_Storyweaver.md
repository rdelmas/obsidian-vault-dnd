# CONTEXT — STORYWEAVER (Extract)

- Master Prompt : v4 (Core, avec commandes d’annexes)
- Annexes : Structures & Schemas ; Stats & Feats
- Commandes d’appel :
  >>> CHARGER ANNEXES — STRUCTURES & SCHEMAS
  >>> CHARGER ANNEXES — STATS & FEATS
- PJ validé : PC_Tyron-Salun_PC-0001.md (Clerc LN, Domaine Commerce, Divine Order Protector)
- Settings mécaniques : 02_Settings_Mechanics.md (validated)
