---
id: "SETTINGS-ANNEX-SCHEMAS"
title: "Structures & Schémas Storyweaver"
category: "annex"
status: "validated"
last_updated: "2026-03-19"
file_role: "structures_schemas"
file_version: "1.2"
schemas_version: "1.2"
supported_types: ["faction","lieu","pnj","item","scene","reference","session","quest","culture"]
---

# Ajoutez ici vos modèles YAML complets pour chaque type.
