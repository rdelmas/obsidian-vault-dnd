prompt_version: "5.3.2"
prompt_date: "2026-03-19"
file_role: "master_prompt"

# MASTER PROMPT — The Storyweaver v5.3.2 (CORE)
# (NOTE: Content truncated placeholder – user already has full v5.3.1 core logic)
# Below is a placeholder header. User will paste the full content manually.

This file is the Master Prompt. Paste the full v5.3.2 prompt content here.
