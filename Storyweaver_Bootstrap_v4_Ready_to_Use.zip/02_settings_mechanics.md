---
id: "SETTINGS-MECH-0001"
title: "Paramètres mécaniques"
category: "settings"
status: "validated"
last_updated: "YYYY-MM-DD"
source: "conversation"
validation_source: "User confirmation"
tags: ["settings/mechanics","status/validated"]
---
# Paramètres
- Système: DnD 5e (2024) ou autre
- Style: RAW | Rule‑of‑Cool | Mix
- Sources autorisées: PHB 2024, DMG, MM, SRD, etc.
- Stat‑blocking: précis | abstrait | suggestion
- Jets: on request | simulate | never
- Difficulté par défaut: Medium
